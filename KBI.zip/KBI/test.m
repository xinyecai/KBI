close all
clear all 
clc
%-----------------------
%Produced by @yushun xiao
%@nuaa
%------------------------
%% ���ò���
problems       = 'DTLZ2';
objDim         = 3;
algorithm_name = {'NSGAII','IBEA','PAES','GrEA','NSGAIII','MOEAD'};
path1          = 'C:\Users\Shaw\Desktop\KBI\data_new\';
space_c       = '-';
str_M          = 'M';
str_D          = 'D';
PF_name        = 'PF';
Rum_num        = size(algorithm_name,2);
%% ��������
cell_arry = cell(Rum_num,1);
str = strcat(path1, algorithm_name, space_c, problems, space_c, num2str(objDim),str_D);
for i = 1 : Rum_num
    cell_arry{i} = load(str{i});
    
end
str_PF = strcat(path1, PF_name, space_c, problems, space_c, num2str(objDim), str_D);
load (str_PF)
%% ���㷽��
sum  = [];
for i = 1 : Rum_num
    PopObj = shift_point(PF, cell_arry{i});
    mmd_XY = my_mmd(PF, PopObj,objDim);
    sum    = [sum, mmd_XY];
end
sum






